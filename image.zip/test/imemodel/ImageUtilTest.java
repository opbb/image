package imemodel;


/**
 * This class acts as a tester class for the ImageUtil class.
 */
public class ImageUtilTest {

/*No tests as all methods within this class have to do with reading, gathering the data, and writing
  that of what is contained within a PPM file.
*/
}